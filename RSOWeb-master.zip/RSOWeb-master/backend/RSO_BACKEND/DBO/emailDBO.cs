using System;

namespace RSO_TEST_API.DBO
{
    public class emailDBO
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}