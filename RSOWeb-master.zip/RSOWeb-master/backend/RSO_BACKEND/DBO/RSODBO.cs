namespace RSO_TEST_API.DBO
{
    public class RSODBO
    {
        public string name { get; set; }
        public string school { get; set; }
    }
}