# RSOWeb
This is a website built to help students easily see which events are available at their university as well as keep track of the events that are happening in the student Organizations that they are a part of. 

